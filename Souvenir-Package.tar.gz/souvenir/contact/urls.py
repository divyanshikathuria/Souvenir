from souvenir.contact.forms import *
from django.conf.urls.defaults import *

urlpatterns = patterns("souvenir.contact.views",
    (r"^contact(\d+)/$", "contact"),
)


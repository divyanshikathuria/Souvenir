from django.contrib import admin
from souvenir.student.models import Profile

class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'date','class_roll_no' )
    search_fields = ('name',)

admin.site.register(Profile, ProfileAdmin)

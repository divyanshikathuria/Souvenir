from django.shortcuts import render_to_response
from mysite.student.models import *

def fulldetail(request):
	"""
	Detail Veiw of data
	"""
	fulldetail = Profile.objects.all().order_by('class_roll_no')
     #   x=0
       # while(fulldetail=fulldetail)
        #    y=x++
     
	return render_to_response("userprofile/profile/fulldetail.html", {"fulldetail" : fulldetail} )

def detail(request):
	"""
	Detail Veiw of data
	"""
	detail = Profile.objects.get(class_roll_no=request.GET['class_roll_no'])
	return render_to_response("userprofile/profile/detail.html", {"detail" : detail} )

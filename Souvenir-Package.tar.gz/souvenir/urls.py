from django.conf.urls.defaults import *
from django.views.generic.simple import direct_to_template
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
		(r'^admin/', include(admin.site.urls)),
		(r'^accounts/', include('userprofile.urls')),
		(r'^$', direct_to_template,
                    { 'template': 'index.html' }, 'index')
)
urlpatterns += patterns('souvenir.contact.views',
		(r'^contact/', 'contact')
)
urlpatterns += patterns('souvenir.student.views',
		(r'^souvenir/fulldetail/', 'fulldetail'),
        (r'^souvenir/detail/', 'detail'),
        (r'^souvenir/CE/', 'ce'),
        (r'^souvenir/ECE/', 'ece'),
        (r'^souvenir/ME/', 'me'),
        (r'^souvenir/PE/', 'pe'),
        (r'^souvenir/CSE/', 'cse'),
        (r'^souvenir/EE/', 'ee'),
        (r'^souvenir/IT/', 'it'),
)
